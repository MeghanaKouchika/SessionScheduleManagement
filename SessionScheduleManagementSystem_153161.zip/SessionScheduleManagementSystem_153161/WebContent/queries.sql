Create ScheduledSessions(id number primary key, name varchar(20), duration number, faculty varchar(20), mode1 varchar(20));
Insert into ScheduledSessions values(1,'Spring', 4, 'Vihar', 'ILT');
Insert into ScheduledSessions values(2,'Struts', 4, 'Tarun', 'ITL');
Insert into ScheduledSessions values(3,'Hibernate', 3, 'Rekha', 'VC');
Commit;
